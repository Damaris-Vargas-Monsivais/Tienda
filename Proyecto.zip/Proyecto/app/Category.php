<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use phpDocumentor\Reflection\Types\This;
use Illuminate\Support\Str;

class Category extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'nombre', 'descripcion','slug', 'icono',
    ];
    //HACEMOS RELACION AL MODELO SUBCATEGORY
    public function Subcategories(){
        //INFORMAMOS EL NOMBRE DE LA CLASE DEL MODELO CON EL QUE LO ESTAMOS RELACIONANDO
        //DEVUELVE EL VALOR AL METODO Subcategories
        return $this->hasMany(Subcategory::class);
    }
    //CON $request DEFINIMOS DONDE QUEREMOS RECIBIR EL OBJETO DE 
    //LA DEPENDENCIA O CLASE Illuminate\Http\Request.
    public function my_store($request){
        //DECLARACION DE LA RELACION 1-MUCHOS EN EL MODELO
        self::create([
            'nombre' => $request -> nombre,
            'descripcion' => $request -> descripcion,
            //GENERAMOS UN SLUG COMPARTIBLE CON URL
            'slug' => Str::slug($request->nombre, '_'), //separa por subguion y quita caracteres especiales
            'icono' => $request -> icono,
        ]);
    }
    public function my_update($request){
        $this->update([
            'nombre' => $request -> nombre,
            'descripcion' => $request -> descripcion,
            //GENERAMOS UN SLUG COMPARTIBLE CON URL
            'slug' => Str::slug($request->nombre, '_'),//separa por subguion y quita caracteres especiales
            'icono' => $request -> icono,
        ]);
    }
}
