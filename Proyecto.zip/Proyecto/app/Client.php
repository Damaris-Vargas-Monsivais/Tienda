<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Client extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'nombre',
        'dni',
        'rif',
        'estado',
        'telefono',
        'email',
    ];
    //HACEMOS RELACION AL MODELO SALES
    public function sales(){
        //INFORMAMOS EL NOMBRE DE LA CLASE DEL MODELO CON EL QUE LO ESTAMOS RELACIONANDO
        //DEVUELVE EL VALOR AL METODO Sales
        return $this->hasMany(Sale::class);
    }
}
