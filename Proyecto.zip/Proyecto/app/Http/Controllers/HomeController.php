<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $comprasmes=DB::select('SELECT month(c.fecha_compra) as mes, sum(c.total) as totalmes from purchases c where c.status="VALID" group by month(c.fecha_compra) order by month(c.fecha_compra) desc limit 12');
        $ventasmes=DB::select('SELECT month(v.datos_rebaja) as mes, sum(v.total) as totalmes from sales v where v.status="VALID" group by month(v.datos_rebaja) order by month(v.datos_rebaja) desc limit 12');


        // $comprasmes=DB::select('SELECT monthname(c.fecha_compra) as mes, sum(c.total) as totalmes from purchases c where c.status="VALID" group by monthname(c.fecha_compra) order by month(c.fecha_compra) desc limit 12');
        // $ventasmes=DB::select('SELECT monthname(v.datos_rebaja) as mes, sum(v.total) as totalmes from sales v where v.status="VALID" group by monthname(v.datos_rebaja) order by month(v.datos_rebaja) desc limit 12');

        $ventasdia=DB::select('SELECT DATE_FORMAT(v.datos_rebaja,"%d/%m/%Y") as dia, sum(v.total) as totaldia from sales v where v.status="VALID" group by v.datos_rebaja order by day(v.datos_rebaja) desc limit 15');
        $totales=DB::select('SELECT (select ifnull(sum(c.total),0) from purchases c where DATE(c.fecha_compra)=curdate() and c.status="VALID") as totalcompra, (select ifnull(sum(v.total),0) from sales v where DATE(v.datos_rebaja)=curdate() and v.status="VALID") as totalventa');
        $productosvendidos=DB::select('SELECT p.codigo as codigo, 
        sum(dv.cantidad) as cantidad, p.nombre as name , p.id as id , p.stock as stock from products p 
        inner join sale_details dv on p.id=dv.product_id 
        inner join sales v on dv.sale_id=v.id where v.status="VALID" 
        and year(v.datos_rebaja)=year(curdate()) 
        group by p.codigo ,p.nombre, p.id , p.stock order by sum(dv.cantidad) desc limit 10');
       
       
        return view('home', compact( 'comprasmes', 'ventasmes', 'ventasdia', 'totales', 'productosvendidos'));
    }
}
