<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ClientUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'nombre'=>'string|required|max:255',
            'dni'=>'string|required|unique:clients,dni,'.$this->route('client')->id.'|min:8|max:8',
            'ruc'=>'nullable|string|unique:clients,ruc,'.$this->route('client')->id.'|min:11|max:11',
            'estado'=>'nullable|string|max:255',
            'telefono'=>'string|nullable|unique:clients,telefono,'.$this->route('client')->id.'|min:10|max:10',
            'email'=>'string|nullable|unique:clients,email,'.$this->route('client')->id.'|max:255|email:rfc,dns',
        ];
    }
    public function messages()
    {
        return[
            'nombre.required'=>'Este campo es requerido.',
            'nombre.string'=>'El valor no es correcto.',
            'nombre.max'=>'Solo se permite 255 caracteres.',

            'dni.string'=>'El valor no es correcto.',
            'dni.required'=>'Este campo es requerido.',
            'dni.unique'=>'Este DNI ya se encuentra registrado.',
            'dni.min'=>'Se requiere de 8 caracteres.',
            'dni.max'=>'Solo se permite 8 caracteres.',
            
            'ruc.string'=>'El valor no es correcto.',
            'ruc.unique'=>'El número de RUC ya se encuentra registrado.',
            'ruc.min'=>'Se requiere de 11 caracteres.',
            'ruc.max'=>'Solo se permite 11 caracteres.',

            'estado.string'=>'El valor no es correcto.',
            'estado.max'=>'Solo se permite 255 caracteres.',
            
            'telefono.string'=>'El valor no es correcto.',
            'telefono.unique'=>'El número de celular ya se encuentra registrado.',
            'telefono.min'=>'Se requiere de 9 caracteres.',
            'telefono.max'=>'Solo se permite 9 caracteres.',

            'email.string'=>'El valor no es correcto.',
            'email.unique'=>'La dirección de correo electrónico ya se encuentra registrada.',
            'email.max'=>'Solo se permite 255 caracteres.',
            'email.email'=>'No es un correo electrónico.',
        ];
    }
}
