<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ProductUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            "nombre"=>'required|unique:products,nombre,'.$this->route('product')->id.'|string',
            "codigo"=>'nullable|string',
            "category"=>'require',
            "precio_venta"=>'string|required',
            "descripcion_corta"=>'string|required',
            "descripcion_larga"=>'string|required',
            "subcategory_id"=>'string|required',
            "provider_id"=>'string|required',
        ];
    }
    
}
