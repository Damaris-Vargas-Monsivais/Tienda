<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'url', 'imageable'
    ];
     //HACEMOS RELACION AL MODELO
    public function imageable(){
        //ACCEDEREMOS A ESE METODO COMO UNA PROPIEDAD DE RELACION DINAMICA
        //accediendo al nombre del método imageable EN EL MODELO IMAGE
        return $this->morphTo();
    }
}
