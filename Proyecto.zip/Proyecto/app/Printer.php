<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Printer extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'nombre',
    ];
}
