<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Product extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'codigo',
        'nombre',
        'slug',
        'stock',
        'precio_venta',
        'descripcion_corta',
        'descripcion_larga',
        'status',
        'subcategory_id',
        'provider_id',
    ]; 
    //nos permite trabajar con relaciones donde un registro pertenece a otro registro
    public function subcategory(){
        //ACEPTA EL NOMBRE DE LA CLASE/DETERMINA LLAVE FORANEA DEL METODO
        return $this->belongsTo(Subcategory::class);
    }
    //nos permite trabajar con relaciones donde un registro pertenece a otro registro
    public function provider(){
        //ACEPTA EL NOMBRE DE LA CLASE/DETERMINA LLAVE FORANEA DEL METODO
        return $this->belongsTo(Provider::class);
    }
    //relación polimórfica de uno a muchos
    public function images(){
        return $this->morphMany('App\Image','imageable');
    }
    public function tags(){
        //agregaremos las relaciones muchos a muchos
        return $this->belongsToMany(Tag::class);
    }
    public function my_store($request){
        //DECLARACION DE LA RELACION 1-MUCHOS EN EL MODELO
        $product = self::create([
            'codigo' => $request -> codigo,
            'nombre' => $request -> nombre,
             //GENERAMOS UN SLUG COMPARTIBLE CON URL
            'slug' => Str::slug($request -> nombre, '_'),//separa por subguion y quita caracteres especiales
          
            'descripcion_corta' => $request -> descripcion_corta,
            'descripcion_larga' => $request -> descripcion_larga,
            'precio_venta' => $request -> precio_venta,
         
            'subcategory_id' => $request -> subcategory_id,
            'provider_id' => $request -> provider_id,
        ]);
        $product->tags() -> attach($request->get('tags'));
        $this->generate_code($product);
        $this->upload_files($request, $product);
    }
    public function my_update($request){
        $this->update([
            'codigo' => $request -> codigo,
            'nombre' => $request -> nombre,
             //GENERAMOS UN SLUG COMPARTIBLE CON URL
            'slug' => Str::slug($request -> nombre, '_'),//separa por subguion y quita caracteres especiales
           
            'descripcion_corta' => $request -> descripcion_corta,
            'descripcion_larga' => $request -> descripcion_larga,
            'precio_venta' => $request -> precio_venta,
           
            'subcategory_id' => $request -> subcategory_id,
            'provider_id' => $request -> provider_id,
        ]);
        $this->tags() -> sync($request->get('tags'));
        $this->generate_code($this);
    }
    public function generate_code($product){
        $numero = $product->id;
        $numeroConCeros = str_pad($numero, 8, "0", STR_PAD_LEFT);
        $product->update(['codigo'=>$numeroConCeros]);
    
    }
    public function upload_files($request, $product){
        $urlimages= [];
        if($request -> hasFile('images')){
            $images = $request -> file('images');
            foreach($images as $image){
                $nombre =time().$image -> getClientOriginalName();
                $ruta = public_path().'/image';
                $image -> move($ruta, $nombre);
                $urlimages[]['url']='/image/'.$nombre;
            }

        }
        $product -> images()->createMany($urlimages);

    }
    public function status(){
        switch ($this->status){
            case 'ACTIVE':
                return 'Activo';
            case 'DESACTIVED':
                return 'Desactivado';
            default:
            #code...
            break;
        }
    }
    static function get_active_products(){
        return self::where('status', 'ACTIVE');
    }
    
}
