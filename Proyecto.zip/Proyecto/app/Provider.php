<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Provider extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'nombre', 'email', 'numero_rif', 'estado', 'telefono',
    ];
      //HACEMOS RELACION AL MODELO PRODUCT
     public function products(){
        //INFORMAMOS EL NOMBRE DE LA CLASE DEL MODELO CON EL QUE LO ESTAMOS RELACIONANDO
        //DEVUELVE EL VALOR AL METODO products
        return $this->hasMany(Product::class);
    }
}
