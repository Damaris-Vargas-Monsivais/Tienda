<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Purchase extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'provider_id',
        'user_id',
        'fecha_compra',
        'impuesto',
        'total',
        'status',
        'fotos',
    ];
     //HACEMOS RELACION AL MODELO user
    public function user(){
        //ACEPTA EL NOMBRE DE LA CLASE/DETERMINA LLAVE FORANEA DEL METODO
        return $this->belongsTo(User::class);
    }
     //HACEMOS RELACION AL MODELO provider
    public function provider(){
        //ACEPTA EL NOMBRE DE LA CLASE/DETERMINA LLAVE FORANEA DEL METODO
        return $this->belongsTo(Provider::class);
    }
     //HACEMOS RELACION AL MODELO purchaseDetails
    public function purchaseDetails(){
        //INFORMAMOS EL NOMBRE DE LA CLASE DEL MODELO CON EL QUE LO ESTAMOS RELACIONANDO
        //DEVUELVE EL VALOR AL METODO purchaseDetails
        return $this->hasMany(PurchaseDetails::class);
    }
}
