<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'client_id',
        'user_id',
        'datos_rebaja',
        'impuesto',
        'total',
        'status',
    ];
    public function user(){
        return $this->belongsTo(User::class);
    }
    public function client(){
        return $this->belongsTo(Client::class);
    }
    public function saleDetails(){
        return $this->hasMany(saleDetail::class);
    }
}
