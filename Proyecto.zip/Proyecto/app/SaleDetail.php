<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SaleDetail extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'sale_id',
        'product_id',
        'cantidad',
        'precio',
        'descuento',
    ];
    public function product(){
        return $this->belongsTo(Product::class);
    }
}
