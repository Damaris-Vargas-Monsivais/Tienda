<?php

namespace App;
use Illuminate\Support\Facades\Session;
use Illuminate\Database\Eloquent\Model;

class ShoppingCart extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'status',
        'user_id',
        'order_date',
    ];
    //relacion
    protected function shopping_cart_details(){
        return $this ->hasMany(ShoppingCartDetail::class);
    }
    protected function user(){
        return $this ->belongsTo(User::class);
    }
    public static function findOrCreateBySessionId($shopping_cart_id){
        if($shopping_cart_id){
            return ShoppingCart::find($shopping_cart_id);
        }else{
            return ShoppingCart::create();
        }
    }
    public function cantidad_de_productos(){
        return $this ->shopping_cart_details->sum('cantidad');
    }
    public function total_precio(){
        $total=0;
        foreach($this->shopping_cart_details as $key => $shopping_cart_detail){
            $total += $shopping_cart_detail->precio*$shopping_cart_detail->cantidad;
        }
        return $total;
    }
    public static function obtener_carrito_compras_de_session(){
        $session_name ='shopping_cart_id';
        $shopping_cart_id = Session::get($session_name);
        $shopping_cart=self::findOrCreateBySessionId($shopping_cart_id);
        return $shopping_cart;
    }  
    
}
