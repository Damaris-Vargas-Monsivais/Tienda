<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShoppingCartDetail extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'cantidad',
        'precio',
        'shopping_cart_id',
        'product_id',
    ];
    public function product(){
        return $this->belongsTo(Product::class);
    }
}
