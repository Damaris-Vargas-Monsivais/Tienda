<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Subcategory extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'nombre',
        'slug',
        'descripcion',
        'category_id',
    ];
    public function products(){
        return $this->hasMany(Product::class);
    }
    public function my_store($request){
        self::create([
            'nombre' => $request -> nombre,
            'descripcion' => $request -> descripcion,
            'slug' => Str::slug($request->name, '_'),
            'category_id' => $request -> category_id,
        ]);
    }
    public function my_update($request){
        $this->update([
            'nombre' => $request -> nombre,
            'descripcion' => $request -> descripcion,
            'slug' => Str::slug($request->name, '_'),
            
        ]);
    }
}
