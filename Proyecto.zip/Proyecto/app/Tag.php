<?php

namespace App;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
    //NOMBRE DEL ATRIBUTO O CAMPO EN LA BASE DE DATOS
    protected $fillable = [
        'nombre',
        'slug',
        'descripcion',
    ];
    public function products(){
        return $this->belongsToMany(Product::class);
    }
    public function my_store($request){
        self::create([
            'nombre' => $request -> nombre,
            'descripcion' => $request -> descripcion,
            'slug' => Str::slug($request->name, '_'),
        ]);
    }
    public function my_update($request){
        $this->update([
            'nombre' => $request -> nombre,
            'descripcion' => $request -> descripcion,
            'slug' => Str::slug($request->name, '_'),
        ]);
    }
}
