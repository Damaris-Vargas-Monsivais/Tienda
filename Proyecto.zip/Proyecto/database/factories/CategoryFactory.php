<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Category;
use Faker\Generator as Faker;

$factory->define(Category::class, function (Faker $faker) {
    return [
        'nombre' => $faker->word,
        'slug' => $faker->unique()->slug,
        'descripcion' => $faker->sentence($nbWords = 6, $variableNbWords = true),
        'icono' => $faker->randomElement(['icon-fruits',
        'icon-broccoli-1',
        'icon-beef',
        'icon-fish',
        'icon-fast-food',
        'icon-honey',
        'icon-grape',
        'icon-onions',
        'icon-avocado',
        'icon-contain',
        'icon-fresh-juice',
        'icon-newsletter',
        'icon-organic',
        'icon-beer',]),
    ];
});
