<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Printer;
use Faker\Generator as Faker;

$factory->define(Printer::class, function (Faker $faker) {
    return [
        //
    ];
});
