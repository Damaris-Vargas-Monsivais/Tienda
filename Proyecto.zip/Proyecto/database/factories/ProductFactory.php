<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Product;
use Faker\Generator as Faker;

$factory->define(Product::class, function (Faker $faker) {
    return [
        'codigo'=>$faker->ean8,
        'nombre'=>$faker->streetName,
        'slug'=>$faker->unique()->slug,
        'stock'=>$faker->buildingNumber,
        'descripcion_corta'=>$faker->realText($maxNbChars = 360, $indexSize=2),
        'descripcion_larga'=>$faker->sentence($nbWords=6, $variableNbWords=true),
        'precio_venta'=>$faker->randomNumber(2),
        'status'=>'ACTIVE',
        'subcategory_id'=>rand(1,5),
        'provider_id'=>rand(1,5),
    ];
});
