<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Provider;
use Faker\Generator as Faker;

$factory->define(Provider::class, function (Faker $faker) {
    return [
        'nombre'=>$faker->company,
        'email'=>$faker->email,
        'numero_ruc'=>$faker->numberBetween($min = 10000000000, $max = 11111111111),
        'estado'=>$faker->address,
        'telefono'=>$faker->e164PhoneNumber,
    ];
});
