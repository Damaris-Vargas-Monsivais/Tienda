<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\SaleDetail;
use Faker\Generator as Faker;

$factory->define(SaleDetail::class, function (Faker $faker) {
    return [
        //
    ];
});
