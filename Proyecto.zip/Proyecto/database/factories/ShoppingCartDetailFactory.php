<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ShoppingCartDetail;
use Faker\Generator as Faker;

$factory->define(ShoppingCartDetail::class, function (Faker $faker) {
    return [
        //
    ];
});
