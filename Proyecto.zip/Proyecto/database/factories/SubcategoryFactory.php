<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Subcategory;
use Faker\Generator as Faker;

$factory->define(Subcategory::class, function (Faker $faker) {
    return [
        'category_id'=>rand(1,5),
        'slug'=>$faker->unique()->slug,
        'nombre'=>$faker->unique()->word,
        'descripcion'=>$faker->sentence($nbWords = 6, $variableNbWords=true),
    ];
});
