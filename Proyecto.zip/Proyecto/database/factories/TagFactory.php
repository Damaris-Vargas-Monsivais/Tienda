<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Tag;
use Faker\Generator as Faker;

$factory->define(Tag::class, function (Faker $faker) {
    return [
        'nombre'=>$faker->unique()->word,
        'slug'=>$faker->unique()->slug,
        'descripcion'=>$faker->sentence($nbWords = 6, $variableNbWords=true),
    ];
});
