<?php

use Illuminate\Database\Seeder;
use App\Business;

class BusinessTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Business::create([
            'nombre'=>'Nombre de la empresa.',
            'descripcion'=>'Descripción corta de la empresa.',
            'logo'=>'logo.png',
            'email'=>'Ejemplo@gmail.com',
            'estado'=>'Jalisco',
            'ruc'=>'15247895632',
        ]);
    }
}
